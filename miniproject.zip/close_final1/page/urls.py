from django.conf.urls import url
from . import views
from django.contrib import admin

#app_name = 'music'

urlpatterns = [
    url(r'^$', views.Index, name='Index'),
    url(r'^login_user/$', views.login_user, name='login_user'),
    url(r'^staff_login/$', views.staff_login, name='staff_login'),
    url(r'^register/$', views.register, name='register'),
    url(r'^index/$', views.index, name='index'),
   # url(r'^staff_login/allocate_hall1/$', views.allocate_hall1, name='allocate_hall1'),
    url(r'^logout_user/$', views.logout_user, name='logout_user'),
    url(r'^logout_staff/$', views.logout_staff, name='logout_staff'),
    url(r'^staff_login/Addstudent/$', views.upload_csv, name='Addstudent'),
    url(r'^success/$', views.success, name='success'),
    url(r'^hallarrengment/$', views.hallarrengment, name='hallarrengment'),
    url(r'^hall/$', views.hall, name='hall'),
    url(r'^hall1/$', views.hall1, name='hall1'),
    url(r'^(?P<p>[0-9]+)/$', views.hall2, name='hall2'),
    url(r'^(?P<blockno>[0-9]+)/(?P<p>[0-9]+)/$', views.allocate_seat, name='allocate_seat'),
    #url(r'^staff/$', views.staff, name='staff'),

    url(r'^Delete/$', views.Delete, name='Delete'),
    url(r'^Delete1/$', views.Delete1, name='Delete1'),
    url(r'^check/$', views.check, name='check'),
    url(r'^(?P<blockno>[0-9]+)/(?P<p>[0-9]+)/$', views.hall3, name='hall3'),
    url(r'^(?P<blockno>[0-9]+)/(?P<p>[0-9]+)/checkhall/$', views.getcheckhall, name='getcheckhall'),
    url(r'^checkhllstatus/$', views.checkhllstatus, name='checkhllstatus'),
    url(r'^checkhllstatus1/$', views.checkhllstatus1, name='checkhllstatus1'),
    url(r'^(?P<p>[0-9]+)/checkhall/$', views.checkhall, name='checkhall'),
    url(r'^checkallhall/$', views.checkallhall, name='checkallhall'),
    url(r'^(?P<blockno>[0-9]+)/checkhalldet/$', views.checkhalldet, name='checkhalldet'),
    url(r'^(?P<blockno>[0-9]+)/clearhall/$', views.clearhall, name='clearhall'),
    #url(r'^viewstudent/$', views.viewstudent, name='viewstudent'),
    url(r'^viewstudent/$', views.viewstudent, name='viewstudent'),
    url(r'^firstyear/$', views.firstyear, name='firstyear'),
    url(r'^secondyear/$', views.secondyear, name='secondyear'),
    url(r'^thirdyear/$', views.thirdyear, name='thirdyear'),
    url(r'^lastyear/$', views.lastyear, name='lastyear'),
    #url(r'^(?P<movie_id>[0-9]+)/(?P<song_id>[0-9]+)/$', views.Details1, name = 'Details1'),
  #  url(r'^(?P<movie_id>[0-9]+)/favorite/$', views.favorite, name = 'favorite'),
    url(r'^search_seat1/$', views.search_seat1, name='search_seat1'),
    
    
     url(r'^viewstudent/$', views.viewstudent, name='viewstudent'),
    url(r'^firstyear/$', views.firstyear, name='firstyear'),
    url(r'^secondyear/$', views.secondyear, name='secondyear'),
    url(r'^thirdyear/$', views.thirdyear, name='thirdyear'),
    url(r'^lastyear/$', views.lastyear, name='lastyear'),
  
   
    url(r'^staffsearchseat/$', views.staffsearchseat, name='staffsearchseat'),
    url(r'^deptwise/$', views.deptwise, name='deptwise'),
    
]
