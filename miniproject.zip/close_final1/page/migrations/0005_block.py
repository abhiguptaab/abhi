# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('page', '0004_auto_20181010_1545'),
    ]

    operations = [
        migrations.CreateModel(
            name='Block',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('BlockNo', models.IntegerField(max_length=40)),
                ('Status', models.CharField(max_length=40)),
                ('FloorNo', models.ForeignKey(to='page.Department')),
            ],
        ),
    ]
