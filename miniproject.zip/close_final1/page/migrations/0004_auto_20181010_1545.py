# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('page', '0003_hall_arggengment'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='block',
            name='FloorNo',
        ),
        migrations.RenameField(
            model_name='studsit',
            old_name='NoOfStud',
            new_name='STUDDEP',
        ),
        migrations.RemoveField(
            model_name='hall_arggengment',
            name='Status',
        ),
        migrations.AlterField(
            model_name='department',
            name='FloorNo',
            field=models.IntegerField(max_length=40),
        ),
        migrations.DeleteModel(
            name='Block',
        ),
    ]
